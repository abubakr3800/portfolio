# Ahmed Mohamed Abubakr - Portfolio

A modern, responsive portfolio website showcasing my work in electronics and web development.

## Features

- **Modern Design**: Clean, professional design with smooth animations
- **Responsive Layout**: Works perfectly on desktop, tablet, and mobile devices
- **Interactive Projects**: Filter projects by category (Electronics/Web Development)
- **Dynamic Content**: All content is loaded from JSON data for easy updates
- **Project Gallery**: Modal popups with project details and image galleries
- **Live Project Links**: Direct links to live web projects
- **Certificates Section**: Showcase of professional certifications
- **Contact Form**: Functional contact form with SMTP.js email integration
- **Smooth Scrolling**: Enhanced user experience with smooth navigation

## Project Structure

```
portfolio/
├── index.html              # Main portfolio page
├── data/
│   └── portfolio.json      # All portfolio data
├── css/
│   └── style.css          # Custom styling
├── js/
│   └── portfolio.js       # JavaScript functionality
├── assets/
│   ├── library/           # Bootstrap and other libraries
│   └── projects/          # Project images
│       ├── electronics/   # Electronics project images
│       └── web/          # Web development project images
└── README.md             # This file
```

## How to Use

1. **View the Portfolio**: Open `index.html` in a web browser
2. **Navigate**: Use the navigation menu to jump to different sections
3. **View Projects**: Click on project cards to see detailed information
4. **Filter Projects**: Use the filter buttons to show specific project categories
5. **View Certificates**: Click on certificate cards to see detailed information
6. **Contact Form**: Use the contact form to send messages directly to your email

## Customization

### Updating Personal Information

Edit `data/portfolio.json` to update:
- Personal details (name, contact info, location)
- Education information
- Work experience
- Skills and technologies
- Project details and images

### Adding New Projects

1. Add project images to the appropriate folder in `assets/projects/`
2. Update the JSON data in `data/portfolio.json`:
   ```json
   {
     "name": "Project Name",
     "description": "Project description",
     "image": "path/to/image.png",
     "liveUrl": "https://your-project-url.com",
     "technologies": ["Tech1", "Tech2"]
   }
   ```

### Adding Certificates

1. Add certificate images to `assets/certificates/`
2. Update the JSON data in `data/portfolio.json`:
   ```json
   {
     "name": "Certificate Name",
     "issuer": "Issuing Organization",
     "date": "Date Earned",
     "image": "path/to/certificate.png"
   }
   ```

### Setting Up Email Contact Form

1. Sign up for a free SMTP token at [SMTP.js](https://smtpjs.com/)
2. Update the `SECURE_TOKEN` in `js/config.js` with your token
3. Customize email settings in the config file as needed

### Styling Changes

Modify `css/style.css` to customize:
- Colors (CSS variables in `:root`)
- Typography
- Layout and spacing
- Animations and effects

## Technologies Used

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with CSS Grid and Flexbox
- **JavaScript (ES6+)**: Dynamic content loading and interactions
- **Bootstrap 5**: Responsive framework
- **Font Awesome**: Icons

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Local Development

1. Clone or download the project files
2. Open `index.html` in a web browser
3. For development, use a local server to avoid CORS issues with JSON loading

## Data Structure

The portfolio uses a JSON file (`data/portfolio.json`) with the following structure:

```json
{
  "personal": {
    "name": "Full Name",
    "location": "City, Country",
    "phone": "Phone Number",
    "email": "email@example.com",
    "objective": "Career objective"
  },
  "education": {
    "degree": "Degree Name",
    "institution": "Institution Name",
    "year": "Graduation Year"
  },
  "experience": [
    {
      "title": "Job Title",
      "company": "Company Name",
      "period": "Duration",
      "description": ["Achievement 1", "Achievement 2"]
    }
  ],
  "volunteering": [
    {
      "title": "Role",
      "organization": "Organization",
      "role": "Specific Role",
      "achievements": ["Achievement 1", "Achievement 2"]
    }
  ],
  "skills": {
    "technical": ["Skill 1", "Skill 2"],
    "teaching": ["Teaching Skill 1", "Teaching Skill 2"],
    "languages": ["Language 1", "Language 2"]
  },
  "projects": {
    "electronics": [
      {
        "name": "Project Name",
        "description": "Project description",
        "image": "path/to/image.png",
        "technologies": ["Tech1", "Tech2"]
      }
    ],
    "web": [
      {
        "name": "Project Name",
        "description": "Project description",
        "images": ["image1.jpg", "image2.jpg"],
        "technologies": ["Tech1", "Tech2"]
      }
    ]
  }
}
```

## Contact

For any questions or suggestions, please contact:
- Email: ahmed.mo.abubakr@gmail.com
- Phone: 01113284597
- Location: Giza, Egypt 